import User from "../models/User.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import { sendResetPasswordEmail } from "../utils/resetPasswordEmail.js";
import { sendVerificationEmail } from "../utils/verificationEmail.js";

// ================= GENERATE ACCOUNT NUMBER =================
const generateAccountNumber = () => {
  return Math.floor(
    1000000000 + Math.random() * 9000000000
  ).toString();
};

// ================= REGISTER =================
export const register = async (req, res) => {
  try {
    const { fullname, email, password } = req.body;

    if (!fullname || !email || !password) {
      return res.status(400).json({
        success: false,
        message: "All fields are required",
      });
    }

    const existingUser = await User.findOne({ email });

    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: "Email already exists",
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const verificationToken = crypto
      .randomBytes(32)
      .toString("hex");

    const user = await User.create({
      fullname,
      email,
      password: hashedPassword,
      accountNumber: generateAccountNumber(),
      verificationToken,
      isVerified: false,
    });

    console.log("👤 User created:", user.email);
    console.log("📧 Attempting to send verification email...");

    // Do NOT block the registration response on email delivery.
    // The backend runs on Render (persistent Node process), so the
    // background send completes even after the response is returned.
    // If the email fails, the user record still exists and the token is
    // stored, so the account is not lost.
    sendVerificationEmail(user.email, verificationToken)
      .then(() => {
        console.log("✅ Verification email sent successfully!");
      })
      .catch((emailError) => {
        console.error("❌ Verification email failed (non-fatal):");
        console.error(emailError);
      });

    return res.status(201).json({
      success: true,
      message:
        "Registration successful. Please check your email to verify your account.",
    });

  } catch (error) {
    console.error("❌ Registration error:", error);

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// ================= LOGIN =================
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: "Email and password are required",
      });
    }

    const user = await User.findOne({ email }).select("+password");

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    // Email verification check
    if (!user.isVerified) {
      return res.status(401).json({
        success: false,
        message:
          "Please verify your email before logging in.",
      });
    }

    // Frozen account check
    if (user.isFrozen) {
      return res.status(403).json({
        success: false,
        message:
          "Your account has been frozen. Please contact support.",
      });
    }

    const isMatch = await bcrypt.compare(
      password,
      user.password
    );

    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: "Invalid password",
      });
    }

    const token = jwt.sign(
      {
        id: user._id,
        role: user.role,
      },
      process.env.JWT_SECRET,
      {
        expiresIn: process.env.JWT_EXPIRES || "7d",
      }
    );

    return res.status(200).json({
      success: true,
      message: "Login successful",
      token,

      user: {
        id: user._id,
        fullname: user.fullname,
        email: user.email,
        accountNumber: user.accountNumber,
        balance: user.balance,
        profileImage: user.profileImage,
        role: user.role,
      },
    });

  } catch (error) {
    console.error("❌ Login error:", error);

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// ================= FORGOT PASSWORD =================
export const forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({
        success: false,
        message: "Email is required",
      });
    }

    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    // Generate reset token
    const token = crypto
      .randomBytes(32)
      .toString("hex");

    user.resetPasswordToken = token;

    user.resetPasswordExpires = new Date(
      Date.now() + 15 * 60 * 1000
    );

    await user.save();

    console.log("📧 Sending password reset email...");

    await sendResetPasswordEmail(
      user.email,
      token
    );

    console.log("✅ Password reset email sent!");

    return res.status(200).json({
      success: true,
      message:
        "Password reset link sent to your email.",
    });

  } catch (error) {
    console.error("❌ Forgot password error:", error);

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// ================= RESET PASSWORD =================
export const resetPassword = async (req, res) => {
  try {
    const { token } = req.params;
    const { password } = req.body;

    if (!token || !password) {
      return res.status(400).json({
        success: false,
        message: "Token and password are required.",
      });
    }

    const user = await User.findOne({
      resetPasswordToken: token,
    }).select(
      "+resetPasswordToken +resetPasswordExpires"
    );

    if (!user) {
      return res.status(400).json({
        success: false,
        message: "Invalid reset token.",
      });
    }

    if (
      !user.resetPasswordExpires ||
      user.resetPasswordExpires < new Date()
    ) {
      return res.status(400).json({
        success: false,
        message: "Reset link has expired.",
      });
    }

    const hashedPassword = await bcrypt.hash(
      password,
      12
    );

    user.password = hashedPassword;
    user.resetPasswordToken = null;
    user.resetPasswordExpires = null;

    await user.save();

    return res.status(200).json({
      success: true,
      message: "Password reset successful.",
    });

  } catch (error) {
    console.error("❌ Reset password error:", error);

    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// ================= VERIFY EMAIL =================
export const verifyEmail = async (req, res) => {
  try {
    const { token } = req.params;

    if (!token) {
      return res.status(400).send(`
        <h2>Invalid Verification Link ❌</h2>
        <p>No verification token was provided.</p>
      `);
    }

    const user = await User.findOne({
      verificationToken: token,
    });

    if (!user) {
      return res.status(400).send(`
        <h2>Invalid Verification Link ❌</h2>
        <p>This verification link is invalid or has already been used.</p>
      `);
    }

    user.isVerified = true;
    user.verificationToken = null;

    await user.save();

    console.log("✅ Email verified:", user.email);

    return res.status(200).send(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Email Verified</title>
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>

        <body style="
          margin:0;
          font-family:Arial,sans-serif;
          background:#f3f4f6;
          display:flex;
          justify-content:center;
          align-items:center;
          min-height:100vh;
        ">

          <div style="
            background:white;
            padding:40px;
            border-radius:12px;
            text-align:center;
            max-width:500px;
            margin:20px;
            box-shadow:0 10px 30px rgba(0,0,0,0.1);
          ">

            <h1 style="color:#16a34a;">
              Email Verified Successfully ✅
            </h1>

            <p style="color:#374151;font-size:16px;">
              Your Online Banking account has been verified successfully.
            </p>

            <a
              href="https://securetrust-bank-neon.vercel.app/login"
              style="
                display:inline-block;
                margin-top:20px;
                background:#0d6efd;
                color:white;
                text-decoration:none;
                padding:14px 25px;
                border-radius:6px;
                font-weight:bold;
              "
            >
              Click here to login
            </a>

          </div>

        </body>
      </html>
    `);

  } catch (error) {
    console.error("❌ Email verification error:", error);

    return res.status(500).send(`
      <h2>Something went wrong ❌</h2>
      <p>${error.message}</p>
    `);
  }
};