import nodemailer from "nodemailer";

const transporter = nodemailer.createTransport({
  service: "gmail",
  pool: true, // Use a connection pool for better performance
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
  // Add timeout options to prevent hanging
  connectionTimeout: 10000, // 10 seconds
  socketTimeout: 15000, // 15 seconds
  greetingTimeout: 5000, // 5 seconds
});

transporter.verify((error) => {
  if (error) {
    console.error("❌ SMTP ERROR:", error);
  } else {
    console.log("✅ SMTP Server is ready");
  }
});

export default transporter;